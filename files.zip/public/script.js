/**
 * public/script.js
 * Frontend logic: generator, history, socket.io for emails, modal for password
 */
(() => {
  const socket = io();

  // Elements
  const txtEmail = document.getElementById('txt-email');
  const btnGenerate = document.getElementById('btn-generate');
  const btnCopy = document.getElementById('btn-copy');
  const btnRegenerate = document.getElementById('btn-regenerate');
  const historyEl = document.getElementById('history');
  const inboxList = document.getElementById('inbox-list');
  const spamList = document.getElementById('spam-list');
  const unreadBadge = document.getElementById('unread-badge');
  const statusIndicator = document.getElementById('status-indicator');
  const btnConfig = document.getElementById('btn-config');
  const modal = document.getElementById('modal');
  const modalSave = document.getElementById('modal-save');
  const modalCancel = document.getElementById('modal-cancel');
  const appPasswordInput = document.getElementById('app-password');
  const notifySound = document.getElementById('notify-sound');

  const DOMAIN = (window.__DOMAIN__ || (location.hostname.split('.').slice(-2).join('.'))) || 'imambaihaki.my.id';

  // history localStorage
  const HISTORY_KEY = 'random_email_history_v1';
  const MAX_HISTORY = 20;

  function loadHistory() {
    const raw = localStorage.getItem(HISTORY_KEY);
    try {
      return raw ? JSON.parse(raw) : [];
    } catch (e) {
      return [];
    }
  }
  function saveHistory(list) {
    localStorage.setItem(HISTORY_KEY, JSON.stringify(list.slice(0, MAX_HISTORY)));
  }

  function renderHistory() {
    const list = loadHistory();
    historyEl.innerHTML = '';
    list.forEach(email => {
      const li = document.createElement('li');
      li.className = 'flex items-center justify-between gap-2 p-2 rounded hover:bg-white/1';
      li.innerHTML = `<div class="font-mono">${email}</div><div><button class="btn-copy-h item-copy text-sm">Copy</button></div>`;
      historyEl.appendChild(li);
      li.querySelector('.item-copy').addEventListener('click', () => {
        navigator.clipboard.writeText(email);
        showToast('Copied ' + email);
      });
    });
  }

  function randomString() {
    const len = Math.floor(Math.random() * 6) + 10; // 10-15
    const chars = 'abcdefghijklmnopqrstuvwxyz0123456789';
    let s = '';
    for (let i = 0; i < len; i++) {
      s += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return s;
  }

  function generateEmail() {
    const local = randomString();
    const email = `${local}@${DOMAIN}`;
    txtEmail.value = email;
    // put to history
    let list = loadHistory();
    list.unshift(email);
    list = [...new Set(list)]; // unique
    saveHistory(list.slice(0, MAX_HISTORY));
    renderHistory();
    return email;
  }

  btnGenerate.addEventListener('click', generateEmail);
  btnRegenerate.addEventListener('click', () => {
    // same as generate
    generateEmail();
  });
  btnCopy.addEventListener('click', () => {
    if (!txtEmail.value) return showToast('Generate dulu');
    navigator.clipboard.writeText(txtEmail.value);
    showToast('Copied ' + txtEmail.value);
  });

  // Toast
  const toasts = [];
  function showToast(msg, timeout = 3000) {
    const el = document.createElement('div');
    el.className = 'fixed bottom-6 right-6 bg-gray-900 text-white p-3 rounded shadow';
    el.style.zIndex = 9999;
    el.textContent = msg;
    document.body.appendChild(el);
    setTimeout(() => el.remove(), timeout);
  }

  // Email UI helpers
  let unreadCount = 0;
  function incUnread() {
    unreadCount++;
    unreadBadge.textContent = unreadCount;
  }

  function addEmailToList(item) {
    const container = item.mailbox === 'SPAM' ? spamList : inboxList;
    const wrapper = document.createElement('div');
    wrapper.className = 'email-item';
    const left = document.createElement('div');
    left.innerHTML = `<div class="font-semibold">${item.subject || '(No subject)'}</div>
                      <div class="meta">${item.from} • ${new Date(item.date).toLocaleString()}</div>
                      <div class="mt-2 text-sm text-gray-300">${(item.body || '').slice(0, 200)}</div>`;
    const right = document.createElement('div');
    let otpHtml = '';
    if (item.otp) {
      otpHtml = `<div class="otp-badge">${item.otp}</div><div class="mt-2"><button class="btn-copy-otp btn">Copy OTP</button></div>`;
    } else {
      otpHtml = `<div class="text-sm text-gray-400">No OTP found</div>`;
    }
    right.innerHTML = otpHtml;
    wrapper.appendChild(left);
    wrapper.appendChild(right);

    container.prepend(wrapper);

    if (item.otp) {
      // highlight OTP
      const btn = wrapper.querySelector('.btn-copy-otp');
      if (btn) {
        btn.addEventListener('click', () => {
          navigator.clipboard.writeText(item.otp);
          showToast('Copied OTP: ' + item.otp);
        });
      }
      // toast + sound + badge
      showToast('OTP masuk: ' + item.otp);
      try { notifySound.play().catch(()=>{}); } catch(e){}
      incUnread();
    } else {
      // increment unread but less emphasis
      incUnread();
    }
  }

  // Socket listeners
  socket.on('connect', () => {
    console.log('socket connected');
  });

  socket.on('gmail-status', (data) => {
    let label = '🔴 Gmail Disconnected';
    if (!data) data = {};
    if (data.status === 'connected' || data.status === 'attempt-connecting') {
      label = '🟢 Gmail Connected';
    } else if (data.status === 'no-password') {
      label = '🔴 No App Password';
    } else if (data.status === 'disconnected') {
      label = '🔴 Gmail Disconnected';
    }
    statusIndicator.textContent = label;
  });

  socket.on('email', (item) => {
    // item: { uid, mailbox, from, subject, date, body, otp }
    addEmailToList(item);
  });

  // Modal for entering password
  btnConfig.addEventListener('click', () => {
    modal.classList.remove('hidden');
  });
  modalCancel.addEventListener('click', () => {
    modal.classList.add('hidden');
  });
  modalSave.addEventListener('click', async () => {
    const pw = appPasswordInput.value.trim();
    if (!pw) return showToast('Masukkan password');
    try {
      const res = await fetch('/api/password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ password: pw })
      });
      const json = await res.json();
      if (res.ok) {
        showToast('Password disimpan di memory. Server akan coba konek.');
        modal.classList.add('hidden');
        appPasswordInput.value = '';
      } else {
        showToast(json.error || json.message || 'Gagal');
      }
    } catch (e) {
      showToast('Error connecting to server');
    }
  });

  // init
  renderHistory();
  // first generate an email so UI isn't empty
  generateEmail();
})();