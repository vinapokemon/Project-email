/**
 * routes/api.js
 * Exposes:
 *  - GET /api/status -> connected/disconnected/no-password + unread counters (best effort)
 *  - POST /api/password { password } -> set runtime app password (stored in memory)
 */
const express = require('express');

module.exports = ({ runtimeConfig, io }) => {
  const router = express.Router();

  // simple in-memory state observable
  let lastStatus = { status: 'unknown' };
  io.on('connection', socket => {
    // emit current gmail status on new socket
    socket.emit('gmail-status', lastStatus);
    socket.on('disconnect', () => {});
  });

  // The service code emits 'gmail-status' events; reflect them here to memory
  io.on('connection', socket => {
    socket.on('gmail-status', status => {
      lastStatus = status;
    });
  });

  router.get('/status', (req, res) => {
    const hasPassword = !!runtimeConfig.mailPassword;
    res.json({
      gmailUser: process.env.GMAIL_USER || null,
      hasPassword,
      status: lastStatus.status || (hasPassword ? 'connected' : 'no-password')
    });
  });

  router.post('/password', (req, res, next) => {
    try {
      const { password } = req.body;
      if (!password || typeof password !== 'string' || password.trim().length < 6) {
        return res.status(400).json({ error: 'Invalid password' });
      }
      runtimeConfig.mailPassword = password.trim();
      // trigger a status emit so client refreshes
      io.emit('gmail-status', { status: 'attempt-connecting' });
      return res.json({ ok: true, message: 'Password set in runtime. Server will attempt to connect.' });
    } catch (err) {
      next(err);
    }
  });

  return router;
};