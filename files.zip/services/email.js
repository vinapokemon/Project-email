/**
 * services/email.js
 * IMAP connector using imapflow + mailparser
 * Polls INBOX and Spam every pollInterval ms and emits socket events.
 */
const { ImapFlow } = require('imapflow');
const { simpleParser } = require('mailparser');

class EmailService {
  constructor({ user, getPassword, host = 'imap.gmail.com', port = 993, secure = true, pollInterval = 5000, io }) {
    this.user = user;
    this.getPassword = getPassword;
    this.host = host;
    this.port = port;
    this.secure = secure;
    this.pollInterval = pollInterval;
    this.io = io;

    this.client = null;
    this.pollTimer = null;
    this.connected = false;

    // Keep track of seen UIDs per mailbox to avoid duplicates in runtime
    this.seenUids = {
      INBOX: new Set(),
      SPAM: new Set()
    };
  }

  async connect() {
    const pass = this.getPassword();
    if (!this.user || !pass) {
      this.disconnect();
      return;
    }

    if (this.client && this.connected) return;

    // close existing client if any
    if (this.client) {
      try { await this.client.logout(); } catch (e) {}
      this.client = null;
    }

    this.client = new ImapFlow({
      host: this.host,
      port: this.port,
      secure: this.secure,
      auth: { user: this.user, pass }
    });

    try {
      await this.client.connect();
      this.connected = true;
      console.log('IMAP connected');
      this.io.emit('gmail-status', { status: 'connected' });
    } catch (err) {
      console.error('IMAP connect error:', err.message);
      this.connected = false;
      this.io.emit('gmail-status', { status: 'disconnected', error: err.message });
      throw err;
    }
  }

  disconnect() {
    if (this.client && this.connected) {
      try { this.client.logout().catch(()=>{}); } catch (e) {}
    }
    this.client = null;
    this.connected = false;
    this.io.emit('gmail-status', { status: 'disconnected' });
  }

  async start() {
    // start polling loop
    await this.tryConnectIfPossible();

    this.pollTimer = setInterval(async () => {
      try {
        await this.tryConnectIfPossible();
        if (this.connected) {
          await this.checkMailboxes();
        }
      } catch (err) {
        console.error('Polling error:', err.message);
        this.disconnect();
      }
    }, this.pollInterval);
  }

  async tryConnectIfPossible() {
    const pass = this.getPassword();
    if (!pass) {
      if (this.connected) this.disconnect();
      this.io.emit('gmail-status', { status: 'no-password' });
      return;
    }
    if (!this.connected) {
      await this.connect().catch(err => {
        // already emitted status in connect
      });
    }
  }

  async checkMailboxes() {
    if (!this.client || !this.connected) return;

    // Helper to fetch unseen/latest messages for mailboxName
    const fetchMailbox = async (mailboxName, label = 'INBOX') => {
      try {
        // Try opening mailbox
        await this.client.mailboxOpen(mailboxName);
      } catch (err) {
        // mailbox might not exist; skip
        return [];
      }

      // Search for unseen messages (or ALL but we'll filter)
      let uids = await this.client.search({ seen: false });
      // limit to recent 50 to avoid heavy fetch
      uids = uids.slice(-50);

      // filter out already seen in runtime
      uids = uids.filter(uid => !this.seenUids[label].has(uid));
      if (uids.length === 0) return [];

      const messages = [];
      // fetch messages by UID
      for await (let message of this.client.fetch(uids, { source: true, envelope: true, flags: true })) {
        try {
          const parsed = await simpleParser(message.source);
          const from = parsed.from && parsed.from.text ? parsed.from.text : (parsed.from ? JSON.stringify(parsed.from) : '');
          const subject = parsed.subject || '';
          const date = parsed.date ? parsed.date.toISOString() : new Date().toISOString();
          const bodyText = parsed.text || parsed.html || '';

          // extract OTP
          const otpMatch = bodyText && bodyText.match(/\b\d{4,8}\b/);
          const otp = otpMatch ? otpMatch[0] : null;

          const item = {
            uid: message.uid,
            mailbox: label,
            from,
            subject,
            date,
            body: bodyText,
            otp
          };
          messages.push(item);

          // mark as seen in runtime
          this.seenUids[label].add(message.uid);

          // Emit via socket.io
          this.io.emit('email', item);
        } catch (err) {
          console.warn('Failed to parse message:', err);
        }
      }
      return messages;
    };

    // Common Gmail spam mailbox names
    const spamCandidates = ['[Gmail]/Spam', 'Spam', 'Junk'];

    // INBOX
    await fetchMailbox('INBOX', 'INBOX');

    // Spam (try candidates)
    for (const m of spamCandidates) {
      try {
        await fetchMailbox(m, 'SPAM');
        break; // if succeeded at least once → stop
      } catch (e) {
        // continue
      }
    }
  }
}

module.exports = EmailService;