/**
 * server.js
 * Entrypoint: Express + Socket.IO
 */
require('dotenv').config();
const path = require('path');
const http = require('http');
const express = require('express');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const morgan = require('morgan');
const cors = require('cors');
const { Server } = require('socket.io');
const ApiRouter = require('./routes/api');
const EmailService = require('./services/email');

const app = express();
const server = http.createServer(app);
const io = new Server(server);

// Config
const PORT = process.env.PORT || 3000;
const DOMAIN = process.env.DOMAIN || 'imambaihaki.my.id';

// Global in-memory config for GMAIL app password (do not persist)
let runtimeConfig = {
  mailPassword: process.env.GMAIL_APP_PASSWORD || null
};

// Middlewares
app.use(helmet());
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(morgan('combined'));

// Rate limiter (basic)
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 200
});
app.use(limiter);

// Static files
app.use(express.static(path.join(__dirname, 'public')));

// API routes
app.use('/api', ApiRouter({ runtimeConfig, io }));

// Fallback to index.html
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Global error handler
app.use((err, req, res, next) => {
  console.error(err);
  res.status(err.status || 500).json({ error: err.message || 'Internal Server Error' });
});

// Init Email Service
const emailService = new EmailService({
  user: process.env.GMAIL_USER,
  getPassword: () => runtimeConfig.mailPassword,
  host: 'imap.gmail.com',
  port: 993,
  secure: true,
  pollInterval: 5000, // 5 seconds
  io
});

emailService.start().catch(err => {
  console.error('Email service failed to start:', err);
});

// Expose a small health endpoint
app.get('/health', (req, res) => {
  res.json({ status: 'ok', domain: DOMAIN });
});

// Start server
server.listen(PORT, () => {
  console.log(`Server listening on port ${PORT}`);
});