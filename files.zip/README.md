# Random Email Generator + OTP Receiver Dashboard

Features:
- Random email generator for domain: imambaihaki.my.id (random 10-15 lowercase+digits)
- Generator UI: Generate / Copy / Regenerate / History (last 20)
- OTP receiver using Gmail IMAP (imapflow) scanning every 5 seconds
- Extract OTP via regex: \\b\\d{4,8}\\b and highlight/copy
- Realtime updates via Socket.IO
- Dark theme, glassmorphism, responsive, animated feel
- Security: dotenv, rate-limit, helmet, global error handler

How to run (local / Replit / VPS):
1. Copy .env.example to .env and fill GMAIL_USER and GMAIL_APP_PASSWORD (or you can leave APP_PASSWORD empty and set via UI).
2. Install deps:
   npm install
3. Start:
   npm start
4. Open http://localhost:3000

On first run, if you left GMAIL_APP_PASSWORD empty, click "Set App Password" and paste Gmail App Password. The server stores it in memory and will attempt to connect.

Nginx & SSL:
- Use a reverse-proxy with SSL (Let's Encrypt) on domain email.imambaihaki.my.id.
- Example nginx config provided in repo (optional).

Notes:
- Do NOT commit real .env to source control.
- For production, prefer setting GMAIL_APP_PASSWORD via environment variables or a secrets manager.